
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Save, Trash } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Sample notes data - in a real app this would be fetched from an API
const initialNotes = [
  {
    id: '1',
    title: 'Welcome to Qafizz Notes',
    content: 'This is your first note. Start organizing your thoughts!',
    lastEdited: new Date().toLocaleDateString()
  },
  {
    id: '2',
    title: 'Getting Started',
    content: 'Click on any note to view or edit it. Create new notes with the + button.',
    lastEdited: new Date().toLocaleDateString()
  }
];

const NoteEditor = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);
  
  // Find the note in our data
  const note = initialNotes.find(note => note.id === id) || {
    id: id || '0',
    title: 'New Note',
    content: '',
    lastEdited: new Date().toLocaleDateString()
  };

  const [noteTitle, setNoteTitle] = useState(note.title);
  const [noteContent, setNoteContent] = useState(note.content);

  const handleSave = () => {
    setIsSaving(true);
    // In a real app, this would call an API to save the note
    setTimeout(() => {
      setIsSaving(false);
      toast({
        title: "Note saved",
        description: "Your note has been saved successfully.",
      });
      
      // Update the note's last edited date
      note.lastEdited = new Date().toLocaleDateString();
    }, 500);
  };

  const handleDelete = () => {
    // In a real app, this would call an API to delete the note
    toast({
      title: "Note deleted",
      description: "Your note has been deleted.",
      variant: "destructive"
    });
    navigate('/notes');
  };

  return (
    <div className="flex flex-col h-screen">
      <Header title={noteTitle || "New Note"} />
      
      <div className="p-6 flex-1 flex flex-col">
        <div className="flex justify-between items-center mb-4">
          <Button 
            variant="outline" 
            onClick={() => navigate('/notes')}
            className="flex items-center gap-2"
          >
            <ArrowLeft size={16} />
            Back to Notes
          </Button>
          
          <div className="flex gap-2">
            <Button 
              variant="destructive"
              onClick={handleDelete}
              className="flex items-center gap-2"
            >
              <Trash size={16} />
              Delete
            </Button>
            <Button 
              onClick={handleSave}
              disabled={isSaving}
              className="flex items-center gap-2"
            >
              <Save size={16} />
              {isSaving ? 'Saving...' : 'Save'}
            </Button>
          </div>
        </div>
        
        <div className="flex-1 flex flex-col gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Title</label>
            <input
              type="text"
              value={noteTitle}
              onChange={(e) => setNoteTitle(e.target.value)}
              className="w-full bg-background border rounded-md p-2"
              placeholder="Note title"
            />
          </div>
          
          <div className="flex-1">
            <label className="block text-sm font-medium mb-1">Content</label>
            <Textarea 
              value={noteContent}
              onChange={(e) => setNoteContent(e.target.value)}
              className="w-full h-full min-h-[300px] resize-none bg-background"
              placeholder="Write your note here..."
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default NoteEditor;
