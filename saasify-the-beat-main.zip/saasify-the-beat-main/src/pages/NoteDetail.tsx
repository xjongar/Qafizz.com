
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Save, Trash } from 'lucide-react';
import { SaasProduct } from '@/components/SaasCard';
import saasProducts, { updateProduct, deleteProduct } from '@/data/saasProducts';
import Header from '@/components/Header';

const NoteDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);

  // Find the product in our data
  const product = saasProducts.find(product => product.id === id);

  const [productDescription, setProductDescription] = useState(product?.description || '');
  const [productName, setProductName] = useState(product?.name || '');
  const [productPricing, setProductPricing] = useState(product?.pricing || '');

  if (!product) {
    return (
      <div className="flex-1 p-8">
        <h1 className="text-xl font-bold">SaaS product not found</h1>
        <Button 
          variant="outline" 
          onClick={() => navigate('/')}
          className="mt-4"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Directory
        </Button>
      </div>
    );
  }

  const handleSave = () => {
    setIsSaving(true);
    // In a real app, this would call an API to save the product info
    setTimeout(() => {
      setIsSaving(false);
      toast({
        title: "Product updated",
        description: "Your changes have been saved successfully.",
      });
      
      // Update the product in our local data
      updateProduct(id!, {
        name: productName,
        description: productDescription,
        pricing: productPricing
      });
    }, 800); // simulate network delay
  };

  const handleDelete = () => {
    // In a real app, this would call an API to delete the product
    deleteProduct(id!);
    
    toast({
      title: "Product deleted",
      description: "The SaaS product has been removed.",
      variant: "destructive"
    });
    navigate('/');
  };

  return (
    <div className="flex-1 flex flex-col h-full">
      <Header title={productName} />
      
      <div className="p-6 flex-1 flex flex-col">
        <div className="flex justify-between items-center mb-4">
          <Button 
            variant="outline" 
            onClick={() => navigate('/')}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          
          <div className="flex gap-2">
            <Button 
              variant="destructive"
              onClick={handleDelete}
            >
              <Trash className="mr-2 h-4 w-4" />
              Delete
            </Button>
            <Button 
              onClick={handleSave}
              disabled={isSaving}
            >
              <Save className="mr-2 h-4 w-4" />
              {isSaving ? 'Saving...' : 'Save'}
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">Product Name</label>
              <input
                type="text"
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                className="w-full bg-spotify-card border-none p-2 rounded-md"
              />
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">Pricing</label>
              <input
                type="text"
                value={productPricing}
                onChange={(e) => setProductPricing(e.target.value)}
                className="w-full bg-spotify-card border-none p-2 rounded-md"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Description</label>
              <Textarea 
                value={productDescription}
                onChange={(e) => setProductDescription(e.target.value)}
                className="w-full resize-none text-spotify-white bg-spotify-card p-4 h-64"
              />
            </div>
          </div>
          
          <div className="bg-spotify-card p-6 rounded-md">
            <h3 className="text-lg font-bold mb-4">Product Preview</h3>
            <div className="mb-4">
              {product.logo ? (
                <img 
                  src={product.logo} 
                  alt={productName} 
                  className="w-32 h-32 mx-auto object-contain"
                />
              ) : (
                <div className="w-32 h-32 bg-spotify-darkGray rounded-md flex items-center justify-center text-spotify-lightGray mx-auto">
                  {productName.charAt(0)}
                </div>
              )}
            </div>
            <h4 className="font-bold text-lg">{productName}</h4>
            <p className="text-sm text-spotify-lightGray mt-2">{productDescription}</p>
            <p className="text-xs text-spotify-accent mt-2">{productPricing}</p>
            <div className="mt-4">
              <p className="text-xs text-spotify-lightGray">Category: {product.category.charAt(0).toUpperCase() + product.category.slice(1)}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NoteDetail;
