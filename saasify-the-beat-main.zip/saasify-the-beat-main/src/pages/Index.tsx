
import React, { useState } from 'react';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import CategoryCollection from '@/components/CategoryCollection';
import saasProducts from '@/data/saasProducts';

const Index = () => {
  const [activeCategory, setActiveCategory] = useState('home');
  
  const getCategoryTitle = () => {
    switch(activeCategory) {
      case 'home':
        return 'Discover SaaS Products';
      case 'productivity':
        return 'Productivity Tools';
      case 'analytics':
        return 'Analytics Platforms';
      case 'design':
        return 'Design Tools';
      case 'development':
        return 'Development Resources';
      case 'marketing':
        return 'Marketing Solutions';
      default:
        return activeCategory.charAt(0).toUpperCase() + activeCategory.slice(1) + ' SaaS';
    }
  };

  return (
    <div className="flex h-screen w-full overflow-hidden">
      <Sidebar 
        activeCategory={activeCategory} 
        setActiveCategory={setActiveCategory} 
      />
      
      <main className="flex-1 overflow-y-auto">
        <Header title={getCategoryTitle()} />
        
        <div className="p-6">
          <CategoryCollection 
            products={saasProducts}
            activeCategory={activeCategory}
          />
        </div>
      </main>
    </div>
  );
};

export default Index;
