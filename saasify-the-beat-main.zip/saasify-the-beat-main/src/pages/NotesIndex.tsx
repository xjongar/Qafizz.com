
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { Plus, ArrowLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

type Note = {
  id: string;
  title: string;
  content: string;
  lastEdited: string;
};

// Sample notes data
const initialNotes: Note[] = [
  {
    id: '1',
    title: 'Welcome to Qafizz Notes',
    content: 'This is your first note. Start organizing your thoughts!',
    lastEdited: new Date().toLocaleDateString()
  },
  {
    id: '2',
    title: 'Getting Started',
    content: 'Click on any note to view or edit it. Create new notes with the + button.',
    lastEdited: new Date().toLocaleDateString()
  }
];

const NotesIndex = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [notes, setNotes] = useState<Note[]>(initialNotes);
  
  const handleCreateNote = () => {
    const newNote: Note = {
      id: (notes.length + 1).toString(),
      title: 'New Note',
      content: '',
      lastEdited: new Date().toLocaleDateString()
    };
    
    setNotes([...notes, newNote]);
    toast({
      title: "Note created",
      description: "Your new note has been created.",
    });
    
    // Navigate to edit the new note
    navigate(`/notes/${newNote.id}`);
  };
  
  const handleNoteClick = (noteId: string) => {
    navigate(`/notes/${noteId}`);
  };
  
  const handleBackToDirectory = () => {
    navigate('/');
  };

  return (
    <div className="flex flex-col h-screen">
      <Header title="Qafizz Notes" />
      
      <div className="p-6 flex-1">
        <div className="flex justify-between items-center mb-6">
          <Button
            variant="outline"
            onClick={handleBackToDirectory}
            className="flex items-center gap-2"
          >
            <ArrowLeft size={16} />
            Back to SaaS Directory
          </Button>
          
          <Button onClick={handleCreateNote} className="flex items-center gap-2">
            <Plus size={16} />
            New Note
          </Button>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {notes.map((note) => (
            <div
              key={note.id}
              className="bg-card border rounded-lg p-4 cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => handleNoteClick(note.id)}
            >
              <h3 className="font-medium mb-2 truncate">{note.title}</h3>
              <p className="text-sm text-muted-foreground line-clamp-3 mb-4">{note.content}</p>
              <p className="text-xs text-muted-foreground">Last edited: {note.lastEdited}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default NotesIndex;
