
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';

export type SaasProduct = {
  id: string;
  name: string;
  description: string;
  pricing: string;
  logo: string;
  category: string;
  featured?: boolean;
};

type SaasCardProps = {
  product: SaasProduct;
  className?: string;
};

const SaasCard = ({ product, className }: SaasCardProps) => {
  const navigate = useNavigate();

  const handleCardClick = () => {
    // If the product is Qafizz Notes, navigate to the notes interface
    if (product.name === 'Qafizz Notes') {
      navigate('/notes');
    } else {
      // For all other products, navigate to the product detail page
      navigate(`/note/${product.id}`);
    }
  };

  return (
    <div 
      className={cn("saas-card relative cursor-pointer hover:shadow-lg transition-all duration-200", className)}
      onClick={handleCardClick}
    >
      <div className="saas-card-image flex items-center justify-center">
        {product.logo ? (
          <img 
            src={product.logo} 
            alt={`${product.name} logo`} 
            className="w-full h-full object-contain p-4"
          />
        ) : (
          <div className="w-full h-full bg-spotify-darkGray rounded-md flex items-center justify-center text-spotify-lightGray">
            {product.name.charAt(0)}
          </div>
        )}
      </div>
      <h3 className="saas-card-title">{product.name}</h3>
      <p className="saas-card-description">{product.description}</p>
      <div className="saas-card-pricing text-xs text-spotify-lightGray mt-2">{product.pricing}</div>
      {product.featured && (
        <div className="absolute top-2 right-2 bg-spotify-accent text-xs px-2 py-1 rounded-full text-spotify-black font-medium">
          Featured
        </div>
      )}
    </div>
  );
};

export default SaasCard;
