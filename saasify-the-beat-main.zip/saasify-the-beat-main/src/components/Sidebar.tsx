
import React from 'react';
import { Home, Search, PlusSquare, BarChart, Layers, Command, Headphones, Monitor, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import saasProducts, { createProduct } from '@/data/saasProducts';

type CategoryProps = {
  name: string;
  icon: React.ReactNode;
  active?: boolean;
  onClick?: () => void;
};

const Category = ({ name, icon, active, onClick }: CategoryProps) => {
  return (
    <button 
      className={cn(
        "nav-link w-full text-left",
        active && "active"
      )}
      onClick={onClick}
    >
      {icon}
      <span>{name}</span>
    </button>
  );
};

type SidebarProps = {
  activeCategory: string;
  setActiveCategory: (category: string) => void;
};

const Sidebar = ({ activeCategory, setActiveCategory }: SidebarProps) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const categories = [
    { id: 'home', name: 'Discover', icon: <Home size={20} /> },
    { id: 'productivity', name: 'Productivity', icon: <Command size={20} /> },
    { id: 'analytics', name: 'Analytics', icon: <BarChart size={20} /> },
    { id: 'design', name: 'Design', icon: <Layers size={20} /> },
    { id: 'development', name: 'Development', icon: <Monitor size={20} /> },
    { id: 'marketing', name: 'Marketing', icon: <Zap size={20} /> },
  ];

  const handleAddSaaS = () => {
    // In a real app, this would redirect to a form to add a new SaaS
    const newSaaS = {
      name: "New SaaS Product",
      description: "Description for your new SaaS product",
      pricing: "From $X/month",
      logo: "",
      category: 'productivity',
    };
    
    createProduct(newSaaS);
    
    toast({
      title: "New SaaS added",
      description: "Your SaaS product has been added successfully."
    });
    
    navigate('/');
  };

  return (
    <div className="w-64 h-full bg-spotify-black p-2 flex flex-col">
      <div className="py-4 px-4 mb-6">
        <h1 className="text-2xl font-bold text-spotify-white">SaaS Directory</h1>
      </div>
      
      <div className="flex flex-col gap-1">
        {categories.map((category) => (
          <Category 
            key={category.id}
            name={category.name} 
            icon={category.icon}
            active={activeCategory === category.id}
            onClick={() => setActiveCategory(category.id)}
          />
        ))}
      </div>
      
      <div className="mt-8 px-4">
        <div className="border-t border-spotify-darkGray py-4">
          <button 
            className="text-sm text-spotify-lightGray hover:text-spotify-white transition-colors flex items-center gap-2"
            onClick={handleAddSaaS}
          >
            <PlusSquare size={16} />
            Add SaaS Product
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
