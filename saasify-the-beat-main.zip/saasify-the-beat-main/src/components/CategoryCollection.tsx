
import { SaasProduct } from './SaasCard';
import FeaturedSaaS from './FeaturedSaaS';

type CategoryCollectionProps = {
  products: SaasProduct[];
  activeCategory: string;
};

const CategoryCollection = ({ products, activeCategory }: CategoryCollectionProps) => {
  // Filter featured products
  const featuredProducts = products.filter(product => product.featured);
  
  // Filter products by category
  const filteredProducts = activeCategory === 'home'
    ? products
    : products.filter(product => product.category === activeCategory);
  
  // For "Home" category, show featured products and all products
  if (activeCategory === 'home') {
    return (
      <div className="pb-8">
        <FeaturedSaaS 
          title="Featured SaaS Products"
          products={featuredProducts}
        />
        
        <FeaturedSaaS 
          title="All SaaS Products"
          products={products}
        />
      </div>
    );
  }
  
  // For specific categories, show all category products
  return (
    <div className="pb-8">
      <FeaturedSaaS 
        title={activeCategory.charAt(0).toUpperCase() + activeCategory.slice(1) + " SaaS Products"}
        products={filteredProducts}
      />
    </div>
  );
};

export default CategoryCollection;
