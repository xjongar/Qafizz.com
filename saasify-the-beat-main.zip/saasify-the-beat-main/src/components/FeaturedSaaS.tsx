
import { ChevronRight } from 'lucide-react';
import SaasCard, { SaasProduct } from './SaasCard';

type FeaturedSaaSProps = {
  title: string;
  products: SaasProduct[];
  viewAllHref?: string;
};

const FeaturedSaaS = ({ title, products, viewAllHref }: FeaturedSaaSProps) => {
  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-spotify-white">{title}</h2>
        {viewAllHref && (
          <a href={viewAllHref} className="text-sm text-spotify-lightGray hover:text-spotify-white flex items-center gap-1">
            View all <ChevronRight size={16} />
          </a>
        )}
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
        {products.map((product) => (
          <SaasCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export default FeaturedSaaS;
