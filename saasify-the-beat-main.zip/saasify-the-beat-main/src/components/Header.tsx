
import { ChevronLeft, ChevronRight, Bell, User } from 'lucide-react';
import { Input } from '@/components/ui/input';

type HeaderProps = {
  title: string;
};

const Header = ({ title }: HeaderProps) => {
  return (
    <div className="sticky top-0 z-10 bg-spotify-background bg-opacity-95 backdrop-blur-sm p-4 flex justify-between items-center">
      <div className="flex items-center gap-4">
        <div className="flex gap-2">
          <button className="bg-spotify-black rounded-full p-1">
            <ChevronLeft size={20} />
          </button>
          <button className="bg-spotify-black rounded-full p-1">
            <ChevronRight size={20} />
          </button>
        </div>
        <h1 className="text-2xl font-bold hidden md:block">{title}</h1>
      </div>
      
      <div className="hidden md:block max-w-md w-full px-4">
        <div className="relative">
          <Input 
            type="search" 
            placeholder="Search for SaaS products" 
            className="bg-spotify-card text-spotify-white pl-10 py-1.5"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-spotify-lightGray" />
        </div>
      </div>
      
      <div className="flex items-center gap-2">
        <button className="bg-spotify-black rounded-full p-2">
          <Bell size={18} />
        </button>
        <button className="bg-spotify-black rounded-full p-2">
          <User size={18} />
        </button>
      </div>
    </div>
  );
};

const Search = ({ className }: { className?: string }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  );
};

export default Header;
