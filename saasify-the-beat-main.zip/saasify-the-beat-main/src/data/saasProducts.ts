
import type { SaasProduct } from '@/components/SaasCard';

const saasProducts: SaasProduct[] = [
  {
    id: '1',
    name: 'Qafizz Notes',
    description: 'Smart note-taking app with AI categorization and seamless organization.',
    pricing: 'From $8/month',
    logo: 'https://placehold.co/200x200/1DB954/FFFFFF.png?text=QN',
    category: 'productivity',
    featured: true
  },
  {
    id: '2',
    name: 'AnalyticsPro',
    description: 'Enterprise-grade analytics platform with real-time reporting and insights.',
    pricing: 'From $49/month',
    logo: 'https://placehold.co/200x200/FF5A5F/FFFFFF.png?text=AP',
    category: 'analytics',
  },
  {
    id: '3',
    name: 'CloudStore',
    description: 'Secure cloud storage solution with advanced encryption and sharing capabilities.',
    pricing: 'From $15/month',
    logo: 'https://placehold.co/200x200/00A0D1/FFFFFF.png?text=CS',
    category: 'storage',
  },
  {
    id: '4',
    name: 'TaskFlow',
    description: 'Streamline your team workflow with customizable kanban boards and automation.',
    pricing: 'From $12/month',
    logo: 'https://placehold.co/200x200/FFA500/FFFFFF.png?text=TF',
    category: 'productivity',
    featured: true
  },
  {
    id: '5',
    name: 'SecureChat',
    description: 'End-to-end encrypted messaging for teams with compliance features built-in.',
    pricing: 'From $7/month/user',
    logo: 'https://placehold.co/200x200/9B59B6/FFFFFF.png?text=SC',
    category: 'communication',
  },
  {
    id: '6',
    name: 'DesignLab',
    description: 'Collaborative design platform for creating stunning graphics and interfaces.',
    pricing: 'From $19/month',
    logo: 'https://placehold.co/200x200/E91E63/FFFFFF.png?text=DL',
    category: 'design',
    featured: true
  },
  {
    id: '7',
    name: 'DevStack',
    description: 'Complete development environment in the cloud, accessible from anywhere.',
    pricing: 'From $25/month',
    logo: 'https://placehold.co/200x200/3498DB/FFFFFF.png?text=DS',
    category: 'development',
  },
  {
    id: '8',
    name: 'MarketBot',
    description: 'AI-powered marketing automation to boost engagement and conversions.',
    pricing: 'From $35/month',
    logo: 'https://placehold.co/200x200/27AE60/FFFFFF.png?text=MB',
    category: 'marketing',
  },
  {
    id: '9',
    name: 'InvoicePro',
    description: 'Seamless billing and invoice management for businesses of all sizes.',
    pricing: 'From $15/month',
    logo: 'https://placehold.co/200x200/F1C40F/FFFFFF.png?text=IP',
    category: 'finance',
  },
  {
    id: '10',
    name: 'RecruitAI',
    description: 'AI-driven talent acquisition and candidate matching platform.',
    pricing: 'From $99/month',
    logo: 'https://placehold.co/200x200/95A5A6/FFFFFF.png?text=RA',
    category: 'hr',
  }
];

export default saasProducts;

// These functions are no longer specific to notes but to SaaS products in general
export const updateProduct = (id: string, updates: Partial<SaasProduct>): SaasProduct | undefined => {
  const productIndex = saasProducts.findIndex(product => product.id === id);
  if (productIndex !== -1) {
    saasProducts[productIndex] = {
      ...saasProducts[productIndex],
      ...updates
    };
    return saasProducts[productIndex];
  }
  return undefined;
};

export const deleteProduct = (id: string): boolean => {
  const productIndex = saasProducts.findIndex(product => product.id === id);
  if (productIndex !== -1) {
    saasProducts.splice(productIndex, 1);
    return true;
  }
  return false;
};

export const createProduct = (product: Omit<SaasProduct, 'id'>): SaasProduct => {
  const newId = (saasProducts.length + 1).toString();
  const newProduct = {
    id: newId,
    ...product,
  };
  saasProducts.unshift(newProduct);
  return newProduct;
};
